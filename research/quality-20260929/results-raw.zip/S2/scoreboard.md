| family | task | raw | layer | rescues / losses (B vs A) |
| --- | --- | ---: | ---: | --- |
| coding | suite-tar-01 | 0/4 | 4/4 | 4 / 0 |
| coding | xfer-mime-01 | 1/4 | 0/4 | 0 / 1 |
| coding | xfer-zip-01 | 1/4 | 3/4 | 2 / 0 |
| computation | digits | 1/3 | 3/3 | 2 / 0 |
| computation | knapsack | 2/3 | 3/3 | 1 / 0 |
| computation | lcs | 0/3 | 3/3 | 3 / 0 |
| computation | sales | 2/3 | 3/3 | 1 / 0 |
| computation | weblog | 3/3 | 3/3 | 0 / 0 |
| workspace | chain | 2/2 | 2/2 | 0 / 0 |
| workspace | copy | 1/2 | 1/2 | 0 / 0 |
| workspace | dedupeH | 2/2 | 2/2 | 0 / 0 |
| workspace | invoiceH | 2/2 | 2/2 | 0 / 0 |
| workspace | ledgerH | 0/2 | 0/2 | 0 / 0 |
| **total** | | **17/37** | **29/37** | **13 / 1** |

completion tokens: raw 870,344, layer 586,105
